import React, { Suspense, lazy } from 'react';
import { Routes, Route } from 'react-router-dom';
import { AuthProvider, useAuth } from "./context/AuthContext.jsx";
import ProtectedRoute from "./components/ProtectedRoute.jsx";
import Navbar from "./components/Navbar.jsx";
import Auth from "./pages/Auth.jsx";
import ChatBot from "./components/ChatBot.jsx";

// Lazy load Spline-heavy components to isolate potential crashes
const Hero = lazy(() => import("./components/Hero.jsx"));
const Features = lazy(() => import("./components/Features.jsx"));
const Visualizer = lazy(() => import("./components/Visualizer.jsx"));
const Interview = lazy(() => import("./components/Interview.jsx"));
const Analyzer = lazy(() => import("./components/Analyzer.jsx"));
const InterviewPage = lazy(() => import("./pages/InterviewPage.jsx"));

function AppContent() {

  return (
    <div className="min-h-screen w-full bg-white dark:bg-[#16171d]">
      <Navbar />
      <Suspense fallback={<div className="min-h-screen bg-black flex items-center justify-center text-white font-black tracking-widest animate-pulse">LOADING VORA...</div>}>
        <Routes>
          <Route path="/" element={
            <div className="pt-16">
              <Hero />
              <Features />
              <Analyzer />
              <Visualizer />
              <Interview />
              <section id="chat-section" className="w-full min-h-screen flex items-center justify-center bg-black px-6 py-16">
                <div className="w-full max-w-4xl flex items-center justify-center">
                  <ChatBot />
                </div>
              </section>
            </div>
          } />
          <Route path="/auth" element={<Auth />} />
          <Route path="/interview" element={
            <ProtectedRoute>
              <InterviewPage />
            </ProtectedRoute>
          } />
        </Routes>
      </Suspense>
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;