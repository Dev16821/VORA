import React, { useState, useEffect, useRef } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

const problems = [
  {
    title: "1. Two Sum",
    difficulty: "Easy",
    description: "Given an array of integers `nums` and an integer `target`, return indices of the two numbers such that they add up to `target`.\n\nYou may assume that each input would have exactly one solution, and you may not use the same element twice.\n\nYou can return the answer in any order.",
    inputFormat: "`nums`: array of integers, `target`: integer",
    outputFormat: "array of two integers (indices)",
    exampleInput: "nums = [2,7,11,15], target = 9",
    exampleOutput: "[0,1]",
    constraints: "- 2 <= nums.length <= 10^4\n- -10^9 <= nums[i] <= 10^9\n- -10^9 <= target <= 10^9\n- Only one valid answer exists."
  }
];

const InterviewPage = () => {
  const [problem] = useState(problems[0]);
  const [code, setCode] = useState('// Write your solution here...\n');
  const [language] = useState('javascript');
  const [messages, setMessages] = useState([
    { role: 'ai', content: `Hello! I'll be your technical interviewer today. We're looking at the **${problem.title}** problem. Take a moment to read the description on the left. Let me know when you're ready or if you have any questions about the requirements.` }
  ]);
  const [chatInput, setChatInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [output, setOutput] = useState('');
  const [evaluation, setEvaluation] = useState(null);
  const [timeLeft, setTimeLeft] = useState(45 * 60); // 45 minutes
  const chatEndRef = useRef(null);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const formatTime = (seconds) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const handleSendChat = async (e) => {
    e?.preventDefault();
    if (!chatInput.trim() || isTyping) return;

    const userMsg = chatInput;
    setMessages(prev => [...prev, { role: 'user', content: userMsg }]);
    setChatInput('');
    setIsTyping(true);

    try {
      const res = await fetch('http://localhost:5000/api/interview', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'chat',
          problemTitle: problem.title,
          description: problem.description,
          messages: [...messages, { role: 'user', content: userMsg }]
        })
      });
      const data = await res.json();
      setMessages(prev => [...prev, { role: 'ai', content: data.reply }]);
    } catch (error) {
      console.error(error);
      setMessages(prev => [...prev, { role: 'ai', content: "Network error reconnecting to interviewer." }]);
    } finally {
      setIsTyping(false);
    }
  };

  const extractHint = async () => {
    if (isTyping) return;
    setIsTyping(true);
    setMessages(prev => [...prev, { role: 'user', content: "Could I get a slight hint on how to approach this?" }]);
    
    try {
      const res = await fetch('http://localhost:5000/api/interview', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'hint',
          problemTitle: problem.title,
        })
      });
      const data = await res.json();
      setMessages(prev => [...prev, { role: 'ai', content: `**Hint:** ${data.hint}` }]);
    } catch (error) {
      console.error(error);
      setMessages(prev => [...prev, { role: 'ai', content: "**Hint:** Try using a Hash Map." }]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleRunCode = () => {
    // Simple mock runner for visual feedback since real execution requires a sandbox VM
    setOutput('Compiling...\nRunning test cases...\n\nOutput: [0, 1]\nExpected: [0, 1]\nStatus: ACCEPTED ✔️');
  };

  const handleSubmitSolution = async () => {
    setOutput('Submitting solution to AI Evaluator...\nAnalyzing O-Complexity...\nVerifying constraints...');
    setIsTyping(true);
    
    try {
      const res = await fetch('http://localhost:5000/api/interview', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'evaluate',
          problemTitle: problem.title,
          description: problem.description,
          code,
          language
        })
      });
      const data = await res.json();
      setEvaluation(data);
      setOutput('Evaluation Complete. See Dashboard for results.');
      
      // AI Interviewer follows up
      setMessages(prev => [...prev, { role: 'ai', content: `Great work submitting your solution! 🚀\n\nI reviewed it and scored it **${data.score}**. Your Time Complexity was **${data.timeComplexity}** and Space Complexity was **${data.spaceComplexity}**.\n\n${data.feedback}\n\n**Follow up question:** ${data.followUp}` }]);
    } catch (error) {
      console.error(error);
      setOutput('Failed to submit solution. Server unreachable.');
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="pt-24 min-h-screen bg-black text-white p-6 max-w-7xl mx-auto space-y-6">
      {/* Header Bar */}
      <div className="flex items-center justify-between border border-white/10 p-4 rounded-xl bg-zinc-900 shadow-xl">
        <h1 className="font-bold tracking-widest text-cyan-400">NEXABOT INTERVIEW_SIM</h1>
        <div className="font-mono text-xl font-bold {timeLeft < 300 ? 'text-red-400' : 'text-cyan-400'}">⏱ {formatTime(timeLeft)}</div>
      </div>

      {evaluation && (
        <div className="bg-cyan-500/10 border border-cyan-500/30 p-6 rounded-xl animate-pulse">
            <h2 className="text-xl font-black text-cyan-400">Evaluation Dashboard</h2>
            <p className="mt-2 text-white/80">Score: {evaluation.score} | Time: {evaluation.timeComplexity}</p>
            <button onClick={() => setEvaluation(null)} className="mt-4 px-4 py-2 bg-white/10 rounded font-bold">Close Feedback</button>
        </div>
      )}

      {/* Grid Layout safely structured */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left: Problem Panel */}
        <div className="col-span-1 bg-zinc-900 border border-white/10 p-6 rounded-xl">
          <h2 className="text-xl font-black mb-2">{problem.title}</h2>
          <span className="text-xs bg-green-500/20 text-green-400 px-3 py-1 rounded-full">{problem.difficulty}</span>
          <div className="mt-4 text-white/70 prose prose-invert prose-sm"><ReactMarkdown remarkPlugins={[remarkGfm]}>{problem.description}</ReactMarkdown></div>
        </div>

        {/* Center: Editor + Output */}
        <div className="col-span-1 lg:col-span-1 flex flex-col gap-4">
          <div className="bg-zinc-900 border border-white/10 rounded-xl flex flex-col h-[400px]">
             <div className="flex justify-between items-center bg-white/5 p-3 border-b border-white/10">
                <span className="text-xs font-bold text-cyan-400 uppercase">Code Editor</span>
                <div className="flex gap-2">
                    <button onClick={handleRunCode} className="px-3 py-1 bg-white/10 text-xs rounded font-bold">Run</button>
                    <button onClick={handleSubmitSolution} className="px-3 py-1 bg-cyan-500 text-black text-xs rounded font-bold">Submit</button>
                </div>
             </div>
             <textarea 
                value={code} onChange={e => setCode(e.target.value)} 
                className="flex-1 bg-transparent p-4 font-mono text-sm outline-none text-white overflow-auto scrollbar-thin scrollbar-thumb-white/10" 
             />
          </div>

          <div className="bg-zinc-900 border border-white/10 rounded-xl flex flex-col h-[200px]">
             <div className="bg-white/5 p-2 px-3 text-xs font-bold border-b border-white/10 uppercase text-white/50">Output Console</div>
             <pre className="p-4 font-mono text-xs text-green-400 overflow-auto whitespace-pre-wrap scrollbar-thin scrollbar-thumb-white/10">{output || "Test runner initialized..."}</pre>
          </div>
        </div>

        {/* Right: AI Chatbot */}
        <div className="col-span-1 bg-zinc-900 border border-cyan-500/20 rounded-xl flex flex-col h-[616px] relative">
          <div className="bg-gradient-to-r from-cyan-500/20 to-transparent p-4 flex justify-between items-center border-b border-white/10">
             <span className="font-bold text-cyan-400 flex items-center gap-2">🤖 AI Interviewer</span>
             <button onClick={extractHint} className="text-[10px] bg-white/10 px-2 py-1 rounded font-bold hover:bg-white/20">Get Hint</button>
          </div>
          <div className="flex-1 p-4 overflow-y-auto space-y-4 scrollbar-thin scrollbar-thumb-white/10">
            {messages.map((m, i) => (
              <div key={i} className={`flex flex-col ${m.role === 'user' ? 'items-end' : 'items-start'}`}>
                 <div className={`p-3 rounded-lg text-sm max-w-[90%] ${m.role === 'user' ? 'bg-cyan-500/20 text-white border border-cyan-500/30' : 'bg-white/5 text-white/80 border border-white/10'}`}>
                    <ReactMarkdown remarkPlugins={[remarkGfm]}>{m.content}</ReactMarkdown>
                 </div>
              </div>
            ))}
            {isTyping && <div className="text-white/40 text-xs mt-2 italic">Interviewer is typing...</div>}
            <div ref={chatEndRef} />
          </div>
          <form onSubmit={handleSendChat} className="p-3 bg-black/50 border-t border-white/10">
            <input 
              value={chatInput} onChange={e=>setChatInput(e.target.value)} 
              placeholder="Explain your approach..." 
              className="w-full bg-white/5 p-3 rounded-lg outline-none text-sm text-white focus:border focus:border-cyan-500/50" 
            />
          </form>
        </div>

      </div>
    </div>
  );
};

export default InterviewPage;
