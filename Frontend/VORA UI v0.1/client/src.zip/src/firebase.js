import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCZFJPTT9ETxE9oZglOl7RDmOXETJeZU4k",
  authDomain: "nexabot-a479f.firebaseapp.com",
  projectId: "nexabot-a479f",
  storageBucket: "nexabot-a479f.firebasestorage.app",
  messagingSenderId: "83832593184",
  appId: "1:83832593184:web:3351942a340ae794815545",
  measurementId: "G-RKLYY1V2K2"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
export default app;
