import React, { useState, useRef, useEffect } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { useAuth } from '../context/AuthContext';

const ChatBot = () => {
  const { currentUser } = useAuth();
  const [messages, setMessages] = useState([
    { role: 'ai', content: 'Hello! I am NexaBot AI, your advanced coding companion. I can analyze code, detect bugs, review folders, or analyze text files. How can I help you today?' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [files, setFiles] = useState([]);
  const [isRecording, setIsRecording] = useState(false);

  const messagesEndRef = useRef(null);
  const fileInputRef = useRef(null);
  const folderInputRef = useRef(null);
  const textareaRef = useRef(null);

  const scrollToBottom = () => {
    // Prevent the entire page from scrolling down to the chatbot on initial load
    if (messages.length > 1) {
      messagesEndRef.current?.scrollIntoView({ behavior: "smooth", block: "nearest" });
    }
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // File & Folder Processing Logic
  const processFiles = async (selectedFiles) => {
    const validExtensions = ['.txt', '.py', '.cpp', '.java', '.js', '.json', '.md', '.html', '.css'];
    
    // Convert FileList to Array and filter
    const validFiles = Array.from(selectedFiles).filter(file => 
      validExtensions.some(ext => file.name.endsWith(ext))
    );

    if (validFiles.length === 0) {
      alert("No valid files found or selected type not supported.");
      return;
    }

    const newFiles = await Promise.all(validFiles.map(async (file) => {
      const text = await file.text();
      return { name: file.webkitRelativePath || file.name, content: text };
    }));

    // Auto-submit files immediately per user request
    handleSend(null, newFiles);
  };

  const handleFileUpload = (e) => {
    if (e.target.files?.length) {
      processFiles(e.target.files);
    }
  };

  const removeFile = (index) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  };

  // Voice Interaction Logic
  const toggleRecording = () => {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      alert("Speech recognition is not supported in this browser.");
      return;
    }

    if (isRecording) {
      setIsRecording(false);
      return;
    }

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = true;

    recognition.onstart = () => setIsRecording(true);
    
    recognition.onresult = (event) => {
      let finalTranscript = '';
      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          finalTranscript += event.results[i][0].transcript;
        }
      }
      if (finalTranscript) {
        setInput(prev => prev ? prev + ' ' + finalTranscript : finalTranscript);
        // Trigger resize manually on voice input
        setTimeout(() => {
          if(textareaRef.current) {
            textareaRef.current.style.height = 'auto';
            textareaRef.current.style.height = Math.min(textareaRef.current.scrollHeight, 200) + 'px';
          }
        }, 100);
      }
    };

    recognition.onerror = (event) => {
      console.error("Speech Recognition Error:", event.error);
      setIsRecording(false);
    };

    recognition.onend = () => {
      setIsRecording(false);
    };

    recognition.start();
  };

  // Textarea Handlers
  const handleInput = (e) => {
    setInput(e.target.value);
    e.target.style.height = 'auto';
    e.target.style.height = Math.min(e.target.scrollHeight, 200) + 'px';
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend(e);
    }
  };

  const handleSend = async (e, directFiles = null) => {
    e?.preventDefault();
    const activeFiles = directFiles || files;

    if ((!input.trim() && activeFiles.length === 0) || isLoading) return;

    const payload = { message: input, files: activeFiles };
    
    // Determine UX format for optimistic message
    let messageDisplay = input;
    if (activeFiles.length > 0) {
      const fileNames = activeFiles.map(f => f.name).join(', ');
      messageDisplay += messageDisplay ? `\n\n*(Attached ${activeFiles.length} file(s): ${fileNames})*` : `*(Attached ${activeFiles.length} file(s): ${fileNames})*`;
    }

    setMessages(prev => [...prev, { role: 'user', content: messageDisplay }]);
    setInput('');
    setFiles([]);
    setIsLoading(true);

    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto'; // Reset size
    }

    try {
      const response = await fetch('http://localhost:5000/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const data = await response.json();
      if (response.ok) {
        setMessages(prev => [...prev, { role: 'ai', content: data.reply }]);
      } else {
        const errorContent = data.details || data.error || 'AI service is temporarily unavailable.';
        setMessages(prev => [...prev, { role: 'ai', content: `**Error:** ${errorContent}` }]);
      }
    } catch (error) {
      console.error("Chat Error:", error);
      setMessages(prev => [...prev, { role: 'ai', content: "**Connection Error:** Failed to reach the backend server. Please ensure the server is running." }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="w-full flex items-center justify-center">
      {/* Chat Window */}
      <div className="w-full max-w-3xl h-[600px] md:h-[700px] bg-black/90 backdrop-blur-3xl border border-white/10 rounded-3xl shadow-[0_0_50px_rgba(34,211,238,0.2)] overflow-hidden flex flex-col animate-in fade-in slide-in-from-bottom-10 duration-500">
        
        {/* Header */}
        <div className="p-4 md:p-6 border-b border-white/5 bg-white/[0.02] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/50 flex items-center justify-center">
              <svg className="w-6 h-6 text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            </div>
            <div>
              <h3 className="text-sm font-black text-white tracking-widest uppercase">NexaBot <span className="text-cyan-400">AI</span></h3>
              <div className="flex items-center gap-1.5">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></div>
                <span className="text-[10px] font-bold text-white/40 uppercase tracking-tighter">System Intelligence v1.5</span>
              </div>
            </div>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6 scrollbar-hide bg-gradient-to-b from-transparent to-cyan-900/5">
          {messages.map((m, i) => (
            <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'} animate-in fade-in duration-300`}>
              <div className={`max-w-[90%] p-4 rounded-2xl text-[13px] leading-relaxed relative ${
                m.role === 'user' 
                  ? 'bg-gradient-to-br from-cyan-600 to-indigo-700 text-white rounded-tr-none shadow-lg shadow-cyan-900/20 whitespace-pre-wrap' 
                  : 'bg-white/5 border border-white/10 text-white/90 rounded-tl-none markdown-content'
              }`}>
                {m.role === 'user' ? (
                  m.content
                ) : (
                  <ReactMarkdown 
                    remarkPlugins={[remarkGfm]}
                    components={{
                      p: ({node, ...props}) => <p className="mb-3 last:mb-0" {...props} />,
                      h1: ({node, ...props}) => <h1 className="text-cyan-400 font-bold mb-2 mt-4 text-xl" {...props} />,
                      h2: ({node, ...props}) => <h2 className="text-cyan-400 font-bold mb-2 mt-4 text-lg" {...props} />,
                      h3: ({node, ...props}) => <h3 className="text-cyan-400 font-bold mb-2 mt-4 text-base" {...props} />,
                      code: ({node, inline, ...props}) => 
                        inline ? (
                          <code className="bg-white/10 px-1.5 py-0.5 rounded text-cyan-300 font-mono text-[12px]" {...props} />
                        ) : (
                          <div className="my-4 rounded-xl overflow-hidden border border-white/10">
                            <pre className="bg-black/60 p-4 overflow-x-auto scrollbar-hide text-[12px] font-mono">
                              <code className="text-cyan-100" {...props} />
                            </pre>
                          </div>
                        ),
                      ul: ({node, ...props}) => <ul className="list-disc ml-4 space-y-1 mb-3" {...props} />,
                      ol: ({node, ...props}) => <ol className="list-decimal ml-4 space-y-1 mb-3" {...props} />,
                    }}
                  >
                    {m.content}
                  </ReactMarkdown>
                )}
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex justify-start animate-in fade-in duration-300">
              <div className="bg-white/5 border border-white/10 p-4 rounded-2xl rounded-tl-none">
                <div className="flex items-center gap-3">
                  <div className="flex gap-1.5">
                    <div className="w-1.5 h-1.5 rounded-full bg-cyan-500 animate-bounce [animation-delay:-0.3s]"></div>
                    <div className="w-1.5 h-1.5 rounded-full bg-cyan-500 animate-bounce [animation-delay:-0.15s]"></div>
                    <div className="w-1.5 h-1.5 rounded-full bg-cyan-500 animate-bounce"></div>
                  </div>
                  <span className="text-[10px] uppercase font-bold text-cyan-500/50 tracking-widest">Analyzing Data...</span>
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Region */}
        <div className="shrink-0 p-4 md:p-6 border-t border-white/5 bg-white/[0.02]">
          
          {/* Hidden Inputs for File/Folder Upload */}
          <input 
            type="file" 
            ref={fileInputRef} 
            onChange={handleFileUpload} 
            className="hidden" 
            multiple 
            accept=".txt,.py,.cpp,.java,.js,.json,.md,.html,.css"
          />
          <input 
            type="file" 
            ref={folderInputRef} 
            onChange={handleFileUpload} 
            className="hidden" 
            webkitdirectory="true" 
            directory="true"
          />

          {/* Uploaded Files Preview */}
          {files.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-3">
              {files.map((file, idx) => (
                <div key={idx} className="flex items-center gap-2 bg-cyan-900/30 border border-cyan-500/30 px-3 py-1.5 rounded-lg text-[11px] text-cyan-100 uppercase tracking-widest font-bold animate-in fade-in scale-in duration-200">
                  <svg className="w-3.5 h-3.5 text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
                  <span className="truncate max-w-[150px]">{file.name}</span>
                  <button onClick={() => removeFile(idx)} className="ml-1 hover:text-red-400 transition-colors">
                    <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* Form wrapper */}
          <form onSubmit={handleSend} className="relative flex items-end gap-2 bg-black/40 border border-white/10 rounded-2xl p-2 transition-all focus-within:border-cyan-500/50">
            
            {/* Toolbar Buttons */}
            <div className="flex items-center gap-1 mb-1 ml-1">
              <button 
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={!currentUser || isLoading}
                title="Upload File"
                className="p-2.5 rounded-xl hover:bg-white/10 text-white/50 hover:text-cyan-400 transition-all disabled:opacity-30 disabled:hover:bg-transparent"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13"></path></svg>
              </button>
              
              <button 
                type="button"
                onClick={() => folderInputRef.current?.click()}
                disabled={!currentUser || isLoading}
                title="Upload Folder"
                className="p-2.5 rounded-xl hover:bg-white/10 text-white/50 hover:text-cyan-400 transition-all disabled:opacity-30 disabled:hover:bg-transparent"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z"></path></svg>
              </button>
              
              <button 
                type="button"
                onClick={toggleRecording}
                disabled={!currentUser || isLoading}
                title="Voice Input"
                className={`p-2.5 rounded-xl transition-all disabled:opacity-30 disabled:hover:bg-transparent ${isRecording ? 'bg-red-500/20 text-red-500 hover:bg-red-500/30 animate-pulse' : 'hover:bg-white/10 text-white/50 hover:text-cyan-400'}`}
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z"></path></svg>
              </button>
            </div>

            {/* Smart Textarea */}
            <textarea 
              ref={textareaRef}
              rows="1"
              value={input}
              onChange={handleInput}
              onKeyDown={handleKeyDown}
              disabled={!currentUser || isLoading}
              placeholder={currentUser ? "Paste code, upload files, or ask anything..." : "Please login to use the AI chatbot."}
              className="flex-1 max-h-[200px] bg-transparent resize-none border-none py-3 px-2 text-[13px] text-white placeholder-white/20 focus:outline-none scrollbar-hide font-medium disabled:opacity-50 disabled:cursor-not-allowed leading-relaxed"
            />
            {/* Submit Button */}
            <button 
              type="submit"
              disabled={!currentUser || isLoading || (!input.trim() && files.length === 0)}
              className="mb-1 mr-1 p-3 rounded-xl bg-cyan-500 text-black hover:scale-105 active:scale-95 transition-all disabled:opacity-30 disabled:hover:scale-100 disabled:cursor-not-allowed"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M14 5l7 7m0 0l-7 7m7-7H3" />
              </svg>
            </button>
          </form>

          <div className="flex justify-between items-center mt-3 px-2">
            <span className="text-[9px] font-bold text-white/20 uppercase tracking-widest hidden md:inline-block">Enter ↵ to Send &bull; Shift + Enter for new line</span>
            <p className="text-[9px] text-center md:text-right text-white/20 font-bold uppercase tracking-[0.2em] w-full md:w-auto">Powered by Groq &bull; Llama 3</p>
          </div>

        </div>
      </div>
    </div>
  );
};

export default ChatBot;

