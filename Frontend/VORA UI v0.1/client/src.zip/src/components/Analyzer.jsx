import React, { useState } from 'react';
import CodeEditor from './CodeEditor';
import AnalysisResults from './AnalysisResults';
import PerformanceSimulator from './PerformanceSimulator';
// Backend detection integration

const Analyzer = () => {
  const [code, setCode] = useState('');
  const [language, setLanguage] = useState('javascript');
  const [analyzing, setAnalyzing] = useState(false);
  const [results, setResults] = useState(null);
  const [step, setStep] = useState(0);
  const [inputSize, setInputSize] = useState(1000);
  const [simResults, setSimResults] = useState(null);
  const [languageError, setLanguageError] = useState(null);

  const handleAnalyze = async () => {
    if (!code.trim()) {
      setLanguageError("No valid code detected. Please paste a complete function or program.");
      return;
    }
    
    setLanguageError(null);
    setAnalyzing(true);
    setResults(null);
    setSimResults(null);
    setStep(0);

    try {
      const response = await fetch('http://localhost:5000/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code, language })
      });

      if (!response.ok) throw new Error('Analysis failed');
      
      const data = await response.json();

      // Language mismatch check
      if (data.languageMatch === false) {
        setLanguageError(`Language mismatch detected. Please select the correct language (Detected: ${data.detectedLang}).`);
        setAnalyzing(false);
        return;
      }

      setResults(data);
    } catch (error) {
      console.error('Analysis Error:', error);
      setLanguageError('Failed to connect to analysis engine. Please ensure the server is running.');
    } finally {
      setAnalyzing(false);
    }
  };

  const runSimulation = async () => {
    if (!results) return;
    setAnalyzing(true);
    
    try {
      const response = await fetch('http://localhost:5000/api/simulate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          inputSize, 
          complexity: results.complexity.time 
        })
      });

      if (!response.ok) throw new Error('Simulation failed');
      
      const data = await response.json();
      setSimResults(data);
    } catch (error) {
      console.error('Simulation Error:', error);
    } finally {
      setAnalyzing(false);
    }
  };

  return (
    <section className="bg-black text-white py-24 px-6 lg:px-12 relative" id="analyzer">
      <div className="max-w-[1400px] mx-auto space-y-20 relative z-10">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="space-y-4">
            <span className="text-xs font-bold tracking-[0.3em] text-cyan-400 uppercase bg-cyan-400/10 px-4 py-1.5 rounded-full border border-cyan-400/20">
              AI Analysis Module
            </span>
            <h2 className="text-4xl md:text-5xl font-black">
              Nex<span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-indigo-500">Analyzer</span>
            </h2>
          </div>
          <p className="text-white/40 max-w-md text-sm md:text-base leading-relaxed">
            A specialized neural engine for detecting algorithms, calculating complexity, and simulating performance in real-time.
          </p>
        </div>

        {/* Status Messages */}
        {languageError && (
          <div className="bg-red-500/10 border border-red-500/50 p-4 rounded-xl flex items-center gap-4 animate-in slide-in-from-top-4 duration-300">
            <span className="text-2xl">⚠️</span>
            <p className="text-red-500 font-bold text-sm tracking-tight">{languageError}</p>
          </div>
        )}

        {/* Main Interface Block */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          <div className="space-y-6">
            <h3 className="text-xs font-black uppercase tracking-widest text-white/30 ml-2">Source Input</h3>
            <CodeEditor 
              code={code} 
              setCode={setCode} 
              language={language} 
              setLanguage={(lang) => {
                setLanguage(lang);
                setLanguageError(null);
              }} 
              onAnalyze={handleAnalyze}
              analyzing={analyzing}
            />
          </div>

          <div className="space-y-6 flex flex-col h-full">
            <h3 className="text-xs font-black uppercase tracking-widest text-white/30 ml-2">Analysis Vector</h3>
            <div className="flex-1">
              <AnalysisResults 
                results={results} 
                step={step} 
                setStep={setStep} 
              />
            </div>
          </div>
        </div>

        {/* Performance Layer (Visible after analysis) */}
        {results && (
          <div className="pt-20 border-t border-white/5 space-y-12 animate-in fade-in slide-in-from-bottom-10 duration-1000">
            <div className="text-center space-y-2">
              <h3 className="text-2xl font-black text-white/80">Performance Benchmarking</h3>
              <p className="text-white/20 text-sm">Simulate how "{results.algorithm}" scales with synthetic loads.</p>
            </div>
            
            <PerformanceSimulator 
              inputSize={inputSize}
              setInputSize={setInputSize}
              selectedAlgo={results.selectedAlgo}
              isSimulating={analyzing}
              results={simResults}
              onRun={runSimulation}
            />
          </div>
        )}

      </div>

      {/* Background Decor */}
      <div className="absolute top-1/4 right-0 w-[500px] h-[500px] bg-cyan-500/5 rounded-full blur-[120px] pointer-events-none"></div>
      <div className="absolute bottom-1/4 left-0 w-[500px] h-[500px] bg-purple-500/5 rounded-full blur-[120px] pointer-events-none"></div>
    </section>
  );
};

export default Analyzer;
