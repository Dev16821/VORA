import React from 'react';
import Spline from '@splinetool/react-spline';

function Hero() {
  return (
    <div className="relative h-screen w-full bg-black overflow-hidden font-sans">
      {/* Robot Background */}
      <div className="absolute inset-0 z-0">
        <Spline scene="https://prod.spline.design/ajtz4quQYf4o0Ekd/scene.splinecode" />
      </div>

      {/* Futuristic Grid Overlay */}
      <div className="absolute inset-0 z-10 pointer-events-none opacity-20" 
           style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, #333 1px, transparent 0)', backgroundSize: '40px 40px' }}>
      </div>
      
      {/* Vignet / Glow */}
      <div className="absolute inset-0 z-10 pointer-events-none bg-radial-[circle_at_center,_transparent_0%,_black_90%] opacity-60"></div>

      {/* Main Content Overlay */}
      <div className="relative z-20 h-full w-full max-w-[1400px] mx-auto px-6 lg:px-12 flex items-center pointer-events-none">
        <div className="grid grid-cols-12 w-full pt-20">
          
          {/* Left Section */}
          <div className="col-span-12 lg:col-span-4 space-y-12">
            
            {/* Top Quote Box */}
            <div className="bg-white/[0.03] border border-white/[0.05] p-8 rounded-sm relative group max-w-sm pointer-events-auto">
                <div className="absolute top-0 left-0 w-8 h-8 border-t border-l border-white/20"></div>
                <div className="text-2xl text-white/20 font-serif absolute -top-4 left-4">"</div>
                <div className="space-y-4">
                    <p className="text-[10px] font-bold tracking-[0.2em] text-white/40 leading-relaxed uppercase">
                        Audit and optimize my O(N²) algorithm for potential improvements
                    </p>
                    <div className="w-12 h-[1px] bg-white/10"></div>
                    <p className="text-[10px] font-bold tracking-[0.2em] text-white/40 leading-relaxed uppercase">
                        Review and refactor my code base for best practices
                    </p>
                </div>
            </div>

            {/* Main Title */}
            <div className="space-y-2 pointer-events-auto">
                <p className="text-[10px] font-bold tracking-[0.4em] text-white/40 uppercase">
                    Unleash the power of
                </p>
                <h1 className="text-7xl lg:text-8xl font-bold text-white tracking-tight leading-tight">
                    Code<br />
                    Review<br />
                    <span className="relative">
                        AI
                        <span className="absolute -left-4 top-0 bottom-0 w-[2px] bg-red-500/80 shadow-[0_0_15px_rgba(239,68,68,0.5)]"></span>
                    </span>
                </h1>
                <p className="text-xs font-medium text-white/40 pt-4">
                    Your personal expert in all algorithms
                </p>
            </div>
          </div>

          {/* Empty Center */}
          <div className="hidden lg:block lg:col-span-1"></div>

          {/* Right Section: Features Sidebar */}
          <div className="hidden lg:flex lg:col-span-7 flex-col items-end justify-center space-y-4 pointer-events-none">
            
            <div className="relative pointer-events-none">
                <div className="absolute -left-8 top-1/2 -translate-y-1/2 flex flex-col items-center space-y-1 opacity-40">
                    <span className="text-[8px] font-bold tracking-[0.2em] text-white rotate-[-90deg] origin-center whitespace-nowrap uppercase">Intro</span>
                    <div className="w-[1px] h-12 bg-white/20"></div>
                </div>

                <div className="space-y-3 w-64 pointer-events-auto">
                    <div className="flex items-center justify-between border border-white/10 bg-white/[0.02] px-4 py-3 rounded-sm group hover:bg-white/[0.05] transition-all cursor-pointer">
                        <span className="text-[9px] font-bold tracking-[0.2em] text-white/70 uppercase">Analyzing on...</span>
                        <svg className="w-3 h-3 text-white/40 group-hover:rotate-90 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                    </div>

                    <div className="w-full h-px bg-gradient-to-r from-transparent via-white/10 to-transparent my-6"></div>

                    {[
                        'AI Virtual Reviewer',
                        'Real-time Analysis',
                        'Complexity Detection',
                        'Smart Refactoring',
                        'Security Scanning'
                    ].map((feature, idx) => (
                        <div key={idx} className="flex items-center space-x-3 border border-white/5 bg-white/[0.01] px-4 py-2.5 rounded-sm hover:border-white/20 hover:bg-white/[0.03] transition-all cursor-pointer group">
                            <div className="w-1 h-1 bg-white/20 group-hover:bg-cyan-400 transition-colors"></div>
                            <span className="text-[9px] font-bold tracking-[0.2em] text-white/40 group-hover:text-white uppercase">
                                {feature}
                            </span>
                        </div>
                    ))}
                </div>
            </div>

            {/* Menu Label (Vertical) */}
            <div className="fixed right-6 bottom-32 flex flex-col items-center space-y-4 pt-12 pointer-events-auto">
                <div className="flex flex-col space-y-1">
                    {[1,2,3].map(i => <div key={i} className="w-4 h-[1px] bg-white/40 ml-auto"></div>)}
                </div>
                <span className="text-[8px] font-black tracking-[0.3em] text-white/30 rotate-0 uppercase">Menu</span>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}

export default Hero;