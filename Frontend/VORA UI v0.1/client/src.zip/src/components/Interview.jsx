import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Interview = () => {
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  
  const highlights = [
    { text: 'Real Interview Questions', desc: 'Practice curated DSA problems.', icon: '🧠' },
    { text: 'AI Code Feedback', desc: 'Get suggestions and optimization tips.', icon: '🤖' },
    { text: 'Time Complexity Analysis', desc: 'Experience real interview pressure.', icon: '⏱' },
    { text: 'Performance Tracking', desc: 'Track time complexity and accuracy.', icon: '📊' },
  ];

  return (
    <section className="bg-black text-white py-24 px-6 lg:px-12 relative overflow-hidden" id="interview">
      {/* Background Orbs */}
      <div className="absolute top-1/4 -left-20 w-96 h-96 bg-cyan-600/10 rounded-full blur-[120px] pointer-events-none"></div>
      <div className="absolute bottom-1/4 -right-20 w-96 h-96 bg-purple-600/10 rounded-full blur-[120px] pointer-events-none"></div>

      <div className="max-w-[1400px] mx-auto grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
        
        {/* Left Column: Content */}
        <div className="space-y-10 order-2 lg:order-1">
          <div className="space-y-4">
            <span className="text-xs font-bold tracking-[0.3em] text-cyan-400 uppercase bg-cyan-400/5 border border-cyan-400/20 px-4 py-1.5 rounded-full inline-block">
              Interview Mode
            </span>
            <h2 className="text-4xl md:text-6xl font-black leading-tight">
              AI-Powered <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-500">
                Coding Simulator
              </span>
            </h2>
            <p className="text-white/50 text-lg md:text-xl leading-relaxed max-w-xl">
              Practice real technical interviews with AI guidance. Solve challenges, get instant feedback, and sharpen your skills.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {highlights.map((item, idx) => (
              <div key={idx} className="flex gap-4 p-4 rounded-2xl bg-white/[0.02] border border-white/5 group hover:bg-white/[0.04] transition-all cursor-default">
                <div className="text-2xl pt-1 group-hover:scale-110 transition-transform">
                  {item.icon}
                </div>
                <div>
                  <h4 className="font-bold text-white/90">{item.text}</h4>
                  <p className="text-xs text-white/40 mt-1">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="pt-4">
            <button 
              onClick={() => {
                if (currentUser) {
                  navigate('/interview');
                } else {
                  alert('Please login to enter the Interview Simulator.');
                  navigate('/auth');
                }
              }}
              className="px-8 py-4 bg-cyan-500 hover:bg-cyan-400 text-black font-bold rounded-xl transition-all flex items-center gap-3 group shadow-[0_0_30px_rgba(34,211,238,0.3)] hover:shadow-[0_0_50px_rgba(34,211,238,0.5)] active:scale-95"
            >
              Start Mock Interview
              <span className="group-hover:translate-x-1 transition-transform">→</span>
            </button>
          </div>
        </div>

        {/* Right Column: Mock UI Preview */}
        <div className="relative order-1 lg:order-2 group">
          {/* Animated Glow Surround */}
          <div className="absolute -inset-1 bg-gradient-to-r from-cyan-500 to-purple-500 rounded-3xl blur opacity-20 group-hover:opacity-40 transition duration-1000"></div>
          
          <div className="relative bg-zinc-900/90 border border-white/10 rounded-3xl overflow-hidden shadow-2xl backdrop-blur-xl">
            {/* Mock Header */}
            <div className="bg-white/5 px-6 py-4 border-bottom border-white/10 flex items-center justify-between">
              <div className="flex gap-2">
                <div className="w-3 h-3 rounded-full bg-red-500/50"></div>
                <div className="w-3 h-3 rounded-full bg-yellow-500/50"></div>
                <div className="w-3 h-3 rounded-full bg-green-500/50"></div>
              </div>
              <span className="text-xs text-white/30 font-mono tracking-widest">INTERVIEW_SIMULATOR.EXE</span>
            </div>

            {/* Mock Dashboard Area */}
            <div className="p-6 md:p-8 space-y-6 min-h-[400px]">
              {/* Question Area */}
              <div className="space-y-3">
                <div className="h-4 w-3/4 bg-white/10 rounded animate-pulse"></div>
                <div className="h-4 w-1/2 bg-white/5 rounded"></div>
              </div>

              {/* Mock Code Block */}
              <div className="bg-black/50 rounded-xl p-5 font-mono text-sm leading-relaxed border border-white/5">
                <p className="text-purple-400">function <span className="text-blue-400">optimizeData</span>(input) &#123;</p>
                <p className="pl-4 text-white/60">let results = [];</p>
                <p className="pl-4 text-white/60">for (let x of input) &#123;</p>
                <p className="pl-8 text-cyan-400 animate-pulse">// AI suggestion: consider Map()</p>
                <p className="pl-8 text-white/60">results.push(x * 2);</p>
                <p className="pl-4 text-white/60">&#125;</p>
                <p className="pl-4 text-purple-400">return <span className="text-white/60">results;</span></p>
                <p className="text-purple-400">&#125;</p>
              </div>

              {/* AI Feedback Overlay */}
              <div className="absolute top-24 right-4 md:right-8 bg-zinc-800 border border-cyan-500/30 p-4 rounded-xl shadow-2xl scale-95 md:scale-100 hover:scale-105 transition-transform cursor-pointer">
                <div className="flex items-start gap-4">
                  <span className="text-xl">🤖</span>
                  <div className="space-y-2">
                    <p className="text-xs font-bold text-cyan-400 tracking-wider">AI EVALUATOR</p>
                    <p className="text-[11px] text-white/70 max-w-[180px]">"Your approach is linear O(n). Try using a sliding window for O(1) space optimization."</p>
                  </div>
                </div>
              </div>

              {/* Performance Metrics Overlay */}
              <div className="absolute bottom-8 left-4 md:left-8 bg-black/60 backdrop-blur-md border border-white/10 p-4 rounded-xl flex gap-6">
                <div>
                  <p className="text-[10px] text-white/30 uppercase tracking-tighter">Time</p>
                  <p className="text-sm font-bold text-cyan-400 tracking-widest">12:45</p>
                </div>
                <div className="w-px bg-white/10"></div>
                <div>
                  <p className="text-[10px] text-white/30 uppercase tracking-tighter">Complexity</p>
                  <p className="text-sm font-bold text-cyan-400 tracking-widest leading-none">O(N)</p>
                </div>
              </div>

            </div>
          </div>
        </div>

      </div>
    </section>
  );
};

export default Interview;
