import React, { useState, useEffect, useRef } from 'react';

const PerformanceSimulator = ({ inputSize, setInputSize, selectedAlgo, isSimulating, results, onRun }) => {
  const canvasRef = useRef(null);

  useEffect(() => {
    if (results) {
      drawGraph();
    }
  }, [results, selectedAlgo]);

  const drawGraph = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const w = canvas.width = canvas.parentElement.clientWidth;
    const h = canvas.height = 300;
    
    ctx.clearRect(0, 0, w, h);
    
    // Draw Axes
    ctx.strokeStyle = 'rgba(255,255,255,0.05)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(40, 20);
    ctx.lineTo(40, h - 30);
    ctx.lineTo(w - 20, h - 30);
    ctx.stroke();

    // Draw Curve based on Complexity
    ctx.strokeStyle = selectedAlgo?.color || '#a855f7';
    ctx.lineWidth = 3;
    ctx.shadowBlur = 15;
    ctx.shadowColor = selectedAlgo?.color || '#a855f7';
    ctx.beginPath();
    
    const complexityMod = selectedAlgo?.complexity || 'O(n log n)';
    
    for (let i = 0; i <= 60; i++) {
      const x = 40 + (i / 60) * (w - 70);
      let y;
      const n = (i / 60) * inputSize;
      
      switch(complexityMod) {
        case 'O(log n)': y = Math.log2(n || 1) * 20; break;
        case 'O(n)': y = n * 0.025; break;
        case 'O(n log n)': y = n * Math.log2(n || 1) * 0.006; break;
        case 'O(n²)': y = (n * n) * 0.000006; break;
        default: y = 50;
      }
      
      const py = h - 30 - Math.min(y, h - 70);
      if (i === 0) ctx.moveTo(x, py);
      else ctx.lineTo(x, py);
    }
    ctx.stroke();
    ctx.shadowBlur = 0;

    // Draw Labels
    ctx.fillStyle = 'rgba(255,255,255,0.2)';
    ctx.font = '9px font-mono';
    ctx.fillText('TIME (ms)', 5, 15);
    ctx.fillText('INPUT SIZE (n)', w - 70, h - 10);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start animate-in fade-in duration-700">
      
      {/* Controls (4/12) */}
      <div className="lg:col-span-4 space-y-6">
        <div className="bg-zinc-900/50 border border-white/10 rounded-3xl p-8 space-y-8 backdrop-blur-2xl">
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <label className="text-[10px] font-black uppercase tracking-[0.2em] text-white/30">Input Size Simulation</label>
              <span className="text-purple-400 font-mono font-bold bg-purple-500/10 px-3 py-1 rounded-lg">{inputSize.toLocaleString()}</span>
            </div>
            <input 
              type="range" 
              min="100" 
              max="10000" 
              step="100"
              value={inputSize}
              onChange={(e) => setInputSize(Number(e.target.value))}
              className="w-full h-2 bg-white/5 rounded-full appearance-none cursor-pointer accent-purple-500 hover:accent-purple-400 transition-all"
            />
            <div className="flex justify-between text-[9px] text-white/20 font-black uppercase tracking-widest">
              <span>n = 100</span>
              <span>n = 10,000</span>
            </div>
          </div>

          <div className="pt-6 border-t border-white/5">
            <button
              onClick={onRun}
              disabled={isSimulating}
              className={`w-full py-4 rounded-2xl font-black text-xs uppercase tracking-widest transition-all shadow-xl group overflow-hidden relative ${
                isSimulating ? 'bg-white/5 text-white/20 cursor-not-allowed' : 'bg-gradient-to-r from-purple-500 to-indigo-600 text-white hover:scale-[1.02] active:scale-95 shadow-purple-500/20'
              }`}
            >
              <span className="relative z-10 transition-transform group-hover:scale-110 block">
                {isSimulating ? 'Processing...' : 'Run Performance Engine'}
              </span>
              <div className="absolute inset-0 bg-white/10 translate-x-[-100%] group-hover:translate-x-0 transition-transform duration-500"></div>
            </button>
          </div>
        </div>
      </div>

      {/* Results Display (8/12) */}
      <div className="lg:col-span-8 space-y-6">
        {results ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-in slide-in-from-right-8 duration-700">
            
            {/* Metric Cards */}
            <div className="bg-zinc-900/50 border border-white/10 rounded-[32px] p-6 flex items-center gap-6 group hover:border-cyan-500/30 transition-all">
              <div className="w-16 h-16 rounded-2xl bg-cyan-500/10 flex items-center justify-center text-cyan-400 group-hover:scale-110 transition-transform shadow-[0_0_20px_rgba(34,211,238,0.1)]">
                <svg className="w-8 h-8 font-bold" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 8v4l3 2m6-2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
              </div>
              <div>
                <p className="text-[10px] font-black uppercase tracking-widest text-white/20 mb-1">Execution Speed</p>
                <div className="flex items-baseline gap-1">
                  <span className="text-3xl font-black text-white">{results.time}</span>
                  <span className="text-xs font-bold text-white/30 uppercase tracking-widest">ms</span>
                </div>
              </div>
            </div>

            <div className="bg-zinc-900/50 border border-white/10 rounded-[32px] p-6 flex items-center gap-6 group hover:border-purple-500/30 transition-all">
              <div className="w-16 h-16 rounded-2xl bg-purple-500/10 flex items-center justify-center text-purple-400 group-hover:scale-110 transition-transform shadow-[0_0_20px_rgba(168,85,247,0.1)]">
                <svg className="w-8 h-8 font-bold" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z" /></svg>
              </div>
              <div>
                <p className="text-[10px] font-black uppercase tracking-widest text-white/20 mb-1">Memory Footprint</p>
                <div className="flex items-baseline gap-1">
                  <span className="text-3xl font-black text-white">{results.memory}</span>
                  <span className="text-xs font-bold text-white/30 uppercase tracking-widest">MB</span>
                </div>
              </div>
            </div>

            {/* Graph Area */}
            <div className="md:col-span-2 bg-zinc-900/60 border border-white/10 rounded-[40px] p-8 space-y-8 backdrop-blur-3xl relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-purple-500/5 blur-[60px]"></div>
              <div className="flex justify-between items-center relative z-10">
                <div className="space-y-1">
                  <h3 className="font-black text-white/80 tracking-tight">Performance Curve</h3>
                  <p className="text-[10px] font-bold text-white/20 uppercase tracking-[0.2em]">Efficiency Growth Ratio</p>
                </div>
                <div className="flex gap-4 text-[10px] font-black tracking-widest text-white/40 uppercase bg-white/5 px-4 py-2 rounded-full border border-white/10">
                  <span className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full animate-pulse" style={{ background: selectedAlgo?.color || '#a855f7' }}></div>
                    {selectedAlgo?.name || 'Code Analysis'}
                  </span>
                </div>
              </div>
              <div className="w-full relative z-10">
                <canvas ref={canvasRef} className="w-full h-[300px]"></canvas>
              </div>
            </div>

            {/* Efficiency Insights */}
            <div className="md:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-6 pb-6">
              <div className="bg-zinc-900/50 border border-white/10 rounded-3xl p-6 space-y-6">
                <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-white/30 px-2">Simulation Log</h4>
                <div className="space-y-4 px-2">
                  {results.steps.map((step, i) => (
                    <div key={i} className="flex gap-4 items-center">
                      <div className="w-1.5 h-1.5 rounded-full bg-cyan-500 shadow-[0_0_10px_rgba(6,182,212,0.6)] animate-pulse"></div>
                      <p className="text-xs text-white/60 font-medium">{step}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-zinc-900/50 border border-white/10 rounded-3xl p-6 space-y-6">
                <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-white/30 px-2">Performance Alerts</h4>
                <div className="space-y-4 px-2">
                  {results.bottlenecks.length > 0 ? (
                    results.bottlenecks.map((b, i) => (
                      <div key={i} className="flex gap-3 p-4 bg-red-500/5 border border-red-500/20 rounded-2xl group hover:bg-red-500/10 transition-all">
                        <span className="text-red-400 font-bold group-hover:scale-125 transition-transform">⚠</span>
                        <p className="text-xs text-red-500/80 font-bold tracking-tight">{b}</p>
                      </div>
                    ))
                  ) : (
                    <div className="flex gap-3 p-4 bg-green-500/5 border border-green-500/20 rounded-2xl">
                      <span className="text-green-400 font-bold">✓</span>
                      <p className="text-xs text-green-500/80 font-bold tracking-tight">System architecture is optimized for current load.</p>
                    </div>
                  )}
                  <div className="p-5 bg-white/[0.03] rounded-2xl border border-white/5 relative group overflow-hidden">
                    <div className="absolute left-0 top-0 w-1 h-full bg-purple-500 opacity-30"></div>
                    <p className="text-[9px] font-black text-white/20 uppercase mb-2 tracking-[0.2em]">AI Insights</p>
                    <p className="text-xs text-white/60 italic leading-relaxed">
                      "Complexity {selectedAlgo?.complexity || 'O(n)'} identified. Scaling beyond n = 50,000 may require specialized memory indexing."
                    </p>
                  </div>
                </div>
              </div>
            </div>

          </div>
        ) : (
          <div className="h-[550px] flex flex-col items-center justify-center space-y-8 border-2 border-dashed border-white/5 rounded-[48px] p-20 text-center relative group overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-purple-500/5 via-transparent to-cyan-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-1000"></div>
            <div className="w-28 h-28 bg-white/[0.01] rounded-[40px] flex items-center justify-center text-5xl border border-white/10 relative z-10 shadow-2xl transition-all duration-500 group-hover:rotate-[360deg] group-hover:scale-110 group-hover:border-purple-500/30">
              ⚡
            </div>
            <div className="space-y-3 relative z-10">
              <h3 className="text-2xl font-black text-white/60 tracking-tight">Neural Simulator Standby</h3>
              <p className="text-white/20 max-w-[280px] mx-auto text-sm font-medium leading-relaxed">
                Connect the analysis engine to start the multi-dimensional performance simulation.
              </p>
            </div>
            {isSimulating && (
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/60 backdrop-blur-md z-20 rounded-[48px] animate-in fade-in duration-300">
                <div className="w-16 h-16 border-4 border-purple-500/20 border-t-purple-500 rounded-full animate-spin mb-6"></div>
                <p className="text-purple-400 font-bold tracking-[0.3em] text-xs uppercase animate-pulse">Analyzing Vectors...</p>
              </div>
            )}
          </div>
        )}
      </div>

    </div>
  );
};

export default PerformanceSimulator;
