import { useState, useEffect, useRef } from 'react'

const COMPLEXITIES = [
  { key: 'n2', label: 'O(n²) — Bubble Sort', color: '#ff6b6b', fn: n => n * n, checked: true },
  { key: 'nlogn', label: 'O(n log n) — Quick Sort', color: '#00f0ff', fn: n => n * Math.log2(n || 1), checked: true },
  { key: 'n', label: 'O(n) — Linear', color: '#ffd93d', fn: n => n, checked: false },
  { key: 'logn', label: 'O(log n) — Binary Search', color: '#8b5cf6', fn: n => Math.log2(n || 1), checked: false },
  { key: 'c1', label: 'O(1) — Hash Lookup', color: '#4ade80', fn: n => 1, checked: false },
  { key: 'exp', label: 'O(2ⁿ) — Exponential', color: '#f472b6', fn: n => Math.pow(2, Math.min(n, 20)), checked: false },
]

export default function Visualizer() {
  const [checked, setChecked] = useState(COMPLEXITIES.reduce((a, c) => ({ ...a, [c.key]: c.checked }), {}))
  const [maxN, setMaxN] = useState(100)
  const canvasRef = useRef(null)

  function toggle(key) { setChecked(prev => ({ ...prev, [key]: !prev[key] })) }

  useEffect(() => { drawChart() }, [checked, maxN])

  function drawChart() {
    const canvas = canvasRef.current; if (!canvas) return
    const ctx = canvas.getContext('2d')
    const parent = canvas.parentElement
    canvas.width = parent.clientWidth; canvas.height = 360
    const W = canvas.width, H = canvas.height
    const pad = { top: 30, right: 25, bottom: 45, left: 65 }
    const cw = W - pad.left - pad.right, ch = H - pad.top - pad.bottom
    ctx.clearRect(0, 0, W, H)

    const active = COMPLEXITIES.filter(c => checked[c.key])
    let maxV = 0
    active.forEach(c => { const v = c.fn(maxN); if (v < Infinity && v > maxV) maxV = v })
    maxV = Math.max(maxV, 10)

    // Grid
    ctx.strokeStyle = 'rgba(255,255,255,0.04)'; ctx.lineWidth = 1
    for (let i = 0; i <= 5; i++) {
      const y = pad.top + (ch / 5) * i
      ctx.beginPath(); ctx.moveTo(pad.left, y); ctx.lineTo(W - pad.right, y); ctx.stroke()
      ctx.fillStyle = 'rgba(255,255,255,0.25)'; ctx.font = '10px monospace'; ctx.textAlign = 'right'
      ctx.fillText(Math.round(maxV - (maxV / 5) * i).toLocaleString(), pad.left - 8, y + 3)
    }
    for (let i = 0; i <= 5; i++) {
      const x = pad.left + (cw / 5) * i
      ctx.beginPath(); ctx.moveTo(x, pad.top); ctx.lineTo(x, H - pad.bottom); ctx.stroke()
      ctx.fillStyle = 'rgba(255,255,255,0.25)'; ctx.textAlign = 'center'
      ctx.fillText(Math.round((maxN / 5) * i), x, H - pad.bottom + 16)
    }

    // Lines
    active.forEach(({ fn, color, label }) => {
      ctx.beginPath(); ctx.strokeStyle = color; ctx.lineWidth = 2.5
      ctx.shadowColor = color; ctx.shadowBlur = 8
      for (let i = 0; i <= 80; i++) {
        const n = (maxN / 80) * i, v = Math.min(fn(n), maxV)
        const x = pad.left + (n / maxN) * cw, y = pad.top + ch - (v / maxV) * ch
        i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y)
      }
      ctx.stroke(); ctx.shadowBlur = 0
    })

    // Legend
    let lx = pad.left
    active.forEach(({ color, label }) => {
      ctx.fillStyle = color; ctx.fillRect(lx, pad.top - 18, 10, 10)
      ctx.fillStyle = 'rgba(255,255,255,0.5)'; ctx.font = '10px system-ui'; ctx.textAlign = 'left'
      ctx.fillText(label.split('—')[0].trim(), lx + 14, pad.top - 9)
      lx += ctx.measureText(label.split('—')[0].trim()).width + 32
    })
    ctx.fillStyle = 'rgba(255,255,255,0.4)'; ctx.font = '11px system-ui'; ctx.textAlign = 'center'
    ctx.fillText('Input Size (n)', W / 2, H - 4)
  }

  return (
    <section className="bg-black text-white py-24 px-6 lg:px-12" id="visualizer">
      <div className="max-w-[1400px] mx-auto space-y-16">
        
        {/* Header */}
        <div className="text-center space-y-4">
          <span className="text-xs font-bold tracking-[0.3em] text-cyan-400 uppercase bg-cyan-400/10 px-4 py-1.5 rounded-full">
            Performance
          </span>
          <h2 className="text-4xl md:text-5xl font-bold">
            Complexity <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">Visualizer</span>
          </h2>
          <p className="text-white/40 max-w-lg mx-auto text-lg">
            Compare algorithm performance visually and understand time complexity.
          </p>
        </div>

        {/* Visualizer Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
          
          {/* Chart Section (2/3) */}
          <div className="lg:col-span-2 bg-zinc-900/20 border border-white/5 rounded-2xl p-6 md:p-10 min-h-[400px] backdrop-blur-sm shadow-2xl">
            <div className="w-full relative">
              <canvas ref={canvasRef} className="w-full h-[360px]"></canvas>
            </div>
          </div>

          {/* Controls Section (1/3) */}
          <div className="bg-zinc-900/20 border border-white/5 rounded-2xl p-8 space-y-10 backdrop-blur-sm">
            <div className="space-y-6">
              <h3 className="text-lg font-bold tracking-tight">Compare Algorithms</h3>
              <div className="flex flex-col gap-3">
                {COMPLEXITIES.map(c => (
                  <label 
                    key={c.key}
                    className={`flex items-center gap-4 p-3 rounded-xl border transition-all cursor-pointer group hover:bg-white/[0.03] ${
                      checked[c.key] ? 'border-white/10 bg-white/[0.02]' : 'border-transparent'
                    }`}
                  >
                    <div className="relative flex items-center">
                      <input 
                        type="checkbox" 
                        checked={checked[c.key]} 
                        onChange={() => toggle(c.key)}
                        className="peer sr-only"
                      />
                      <div className="w-5 h-5 border-2 border-white/10 rounded-md peer-checked:bg-cyan-500 peer-checked:border-cyan-500 transition-all flex items-center justify-center text-[10px] font-black text-black">
                        {checked[c.key] && '✓'}
                      </div>
                    </div>
                    <span className={`text-sm font-medium flex-1 transition-colors ${
                      checked[c.key] ? 'text-white' : 'text-white/30'
                    }`}>
                      {c.label}
                    </span>
                    <div className="w-3 h-3 rounded-full" style={{ background: c.color }}></div>
                  </label>
                ))}
              </div>
            </div>

            {/* Range Slider */}
            <div className="space-y-6 border-t border-white/5 pt-8">
              <div className="flex items-center justify-between text-sm">
                <label className="text-white/40 font-medium">Input Size (n)</label>
                <span className="font-bold text-cyan-400 bg-cyan-400/10 px-3 py-1 rounded-lg tabular-nums">
                  {maxN}
                </span>
              </div>
              <input 
                type="range" 
                min="10" 
                max="1000" 
                value={maxN} 
                onChange={e => setMaxN(+e.target.value)} 
                className="w-full h-1 bg-white/10 rounded-lg appearance-none cursor-pointer accent-cyan-400 hover:accent-cyan-300 transition-all"
              />
              <div className="flex justify-between text-[10px] uppercase tracking-widest text-white/20 font-bold">
                <span>Min (10)</span>
                <span>Max (1000)</span>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  )
}
