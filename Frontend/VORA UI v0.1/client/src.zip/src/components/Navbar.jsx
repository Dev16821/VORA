import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const { currentUser, logout } = useAuth();
  const navigate = useNavigate();

  const handleLaunchApp = () => {
    if (currentUser) {
      document.getElementById('analyzer_section')?.scrollIntoView({ behavior: 'smooth' });
    } else {
      navigate('/auth');
    }
  };

  const handleLogout = async () => {
    try {
      await logout();
      navigate('/');
    } catch (error) {
      console.error("Logout failed", error);
    }
  };

  const navLinks = [
    { name: 'FEATURES', href: '#features' },
    { name: 'ANALYZER', href: '#analyzer' },
    { name: 'VISUALIZER', href: '#visualizer' },
    { name: 'INTERVIEW', href: '#interview' },
    { name: 'SIMULATOR', href: '#analyzer' },
  ];

  return (
    <nav className="fixed top-0 left-0 w-full z-50 bg-black/40 backdrop-blur-xl border-b border-white/5 transition-all duration-300">
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-12">
        <div className="flex justify-between items-center h-20">
          
          {/* Left section: Logo & Ecosystem */}
          <div className="flex items-center space-x-8">
            <Link to="/" className="flex items-center space-x-2 group">
              <div className="w-8 h-8 bg-cyan-500/10 border border-cyan-500/50 rounded flex items-center justify-center group-hover:bg-cyan-500/20 transition-all">
                <svg className="w-5 h-5 text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                </svg>
              </div>
              <span className="text-xl font-bold tracking-tight text-white">
                CodeNova <span className="text-cyan-400">AI</span>
              </span>
            </Link>

            <button className="hidden lg:flex items-center space-x-2 bg-white/5 hover:bg-white/10 border border-white/10 px-4 py-1.5 rounded-full transition-all group">
              <div className="grid grid-cols-2 gap-0.5">
                {[1,2,3,4].map(i => <div key={i} className="w-1 h-1 bg-white/40 group-hover:bg-white/70 rounded-full"></div>)}
              </div>
              <span className="text-[10px] font-bold tracking-[0.2em] text-white/70 uppercase">Our Ecosystem</span>
            </button>
          </div>

          {/* Center section: Navigation Links */}
          <div className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="text-[11px] font-bold tracking-[0.15em] text-white/50 hover:text-white transition-all duration-200"
              >
                {link.name}
              </a>
            ))}
            <button
              onClick={(e) => {
                e.preventDefault();
                if (currentUser) {
                  document.getElementById('chat-section')?.scrollIntoView({ behavior: 'smooth' });
                } else {
                  alert('Please login to access the AI chatbot.');
                  navigate('/auth');
                }
              }}
              className="text-[11px] font-bold tracking-[0.15em] text-cyan-400 hover:text-cyan-200 transition-all duration-200 flex items-center gap-1.5"
            >
              <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"></path></svg>
              CHAT WITH AI
            </button>
          </div>

          {/* Right section: Launch App / Logout */}
          <div className="hidden md:flex items-center space-x-4">
            {currentUser ? (
              <button 
                onClick={handleLogout}
                className="flex items-center space-x-2 bg-transparent hover:bg-white/5 border border-white/20 hover:border-white/40 px-6 py-2 rounded-full text-[11px] font-bold tracking-[0.15em] text-white transition-all group"
              >
                <span>LOGOUT</span>
              </button>
            ) : (
              <button 
                onClick={handleLaunchApp}
                className="flex items-center space-x-2 bg-transparent hover:bg-white/5 border border-white/20 hover:border-white/40 px-6 py-2 rounded-full text-[11px] font-bold tracking-[0.15em] text-white transition-all group"
              >
                <span>LAUNCH APP</span>
                <svg className="w-3 h-3 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
                </svg>
              </button>
            )}
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="p-2 text-white/70 hover:text-white focus:outline-none"
            >
              <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                {isOpen ? (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                ) : (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16" />
                )}
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <div className={`md:hidden ${isOpen ? 'block' : 'hidden'} bg-black/95 backdrop-blur-2xl border-b border-white/5 animate-in fade-in slide-in-from-top-4 duration-300`}>
        <div className="px-6 py-8 space-y-6 flex flex-col items-center">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              className="text-[12px] font-bold tracking-[0.2em] text-white/60 hover:text-white transition-colors"
              onClick={() => setIsOpen(false)}
            >
              {link.name}
            </a>
          ))}
          <button
            onClick={(e) => {
              e.preventDefault();
              setIsOpen(false);
              if (currentUser) {
                document.getElementById('chat-section')?.scrollIntoView({ behavior: 'smooth' });
              } else {
                alert('Please login to access the AI chatbot.');
                navigate('/auth');
              }
            }}
            className="text-[12px] font-bold tracking-[0.2em] text-cyan-400 hover:text-cyan-200 transition-colors flex items-center gap-2"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"></path></svg>
            CHAT WITH AI
          </button>
          {currentUser ? (
            <button 
              onClick={handleLogout}
              className="w-full flex items-center justify-center space-x-2 bg-white/5 border border-white/20 py-3 rounded-full text-[12px] font-bold tracking-[0.2em] text-white"
            >
              <span>LOGOUT</span>
            </button>
          ) : (
            <button 
              onClick={handleLaunchApp}
              className="w-full flex items-center justify-center space-x-2 bg-white/5 border border-white/20 py-3 rounded-full text-[12px] font-bold tracking-[0.2em] text-white"
            >
              <span>LAUNCH APP</span>
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
              </svg>
            </button>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
