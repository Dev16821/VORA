import React from 'react';

const AnalysisResults = ({ results, step, setStep }) => {
  if (!results) {
    return (
      <div className="h-full border-2 border-dashed border-white/5 rounded-3xl flex flex-col items-center justify-center p-12 text-center space-y-4">
        <div className="w-16 h-16 bg-white/[0.02] rounded-2xl flex items-center justify-center text-3xl border border-white/5 shadow-inner">
          🔍
        </div>
        <div className="space-y-2">
          <h3 className="font-bold text-xl text-white/60">Logic Engine Ready</h3>
          <p className="text-white/30 text-sm max-w-xs leading-relaxed">
            Paste your code snippets and click evaluate to run the deep analysis engine.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-in fade-in slide-in-from-bottom-5 duration-700">
      
      {/* Algorithm & Complexity Card */}
      <div className="bg-zinc-900/50 border border-white/10 rounded-2xl p-6 space-y-6 backdrop-blur-xl">
        <div className="space-y-2">
          <p className="text-[10px] font-bold text-cyan-400 uppercase tracking-[0.2em]">Detection</p>
          <h3 className="text-2xl font-black">{results.algorithm}</h3>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white/5 p-3 rounded-xl border border-white/5">
            <p className="text-[10px] text-white/30 uppercase">Time</p>
            <p className="text-xl font-mono font-bold text-white/80">{results.complexity.time}</p>
          </div>
          <div className="bg-white/5 p-3 rounded-xl border border-white/5">
            <p className="text-[10px] text-white/30 uppercase">Space</p>
            <p className="text-xl font-mono font-bold text-white/80">{results.complexity.space}</p>
          </div>
        </div>
      </div>

      {/* Bug & Security Summary */}
      <div className="bg-zinc-900/50 border border-white/10 rounded-2xl p-6 space-y-4 backdrop-blur-xl">
        <p className="text-[10px] font-bold text-yellow-400 uppercase tracking-[0.2em]">Health Status</p>
        <div className="space-y-3">
          {results.bugs.map((bug, i) => (
            <div key={i} className="flex gap-3 items-start p-3 bg-yellow-400/5 border border-yellow-400/20 rounded-xl">
              <span className="text-yellow-400 text-sm">⚠</span>
              <p className="text-xs text-white/70 leading-relaxed">{bug.message}</p>
            </div>
          ))}
          {results.bugs.length === 0 && (
            <div className="flex gap-3 items-start p-3 bg-green-400/5 border border-green-400/20 rounded-xl">
              <span className="text-green-400 text-sm">✓</span>
              <p className="text-xs text-white/70 leading-relaxed">No critical issues detected.</p>
            </div>
          )}
        </div>
      </div>

      {/* Non-Algorithmic Explanation */}
      {results.algorithm === 'None' && results.explanation && (
        <div className="md:col-span-2 bg-blue-500/10 border border-blue-500/20 rounded-2xl p-6 flex flex-col items-center text-center space-y-2 backdrop-blur-xl">
          <span className="text-3xl mb-2">ℹ️</span>
          <h4 className="font-bold text-blue-400">Non-Algorithmic Sequence</h4>
          <p className="text-sm text-blue-200/70 max-w-lg">{results.explanation}</p>
        </div>
      )}

      {/* Visualization / Step Logic (Full Width) */}
      {results.visualization && results.visualization.length > 0 && (
        <div className="md:col-span-2 bg-zinc-900/50 border border-white/10 rounded-2xl p-8 space-y-8 backdrop-blur-xl overflow-hidden">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <h4 className="font-bold">Logic Visualization</h4>
              <p className="text-xs text-white/30">Step-by-step algorithmic breakdown</p>
            </div>
            <div className="flex gap-2">
              <button 
                onClick={() => setStep(s => Math.max(0, s - 1))}
                disabled={step === 0}
                className="w-8 h-8 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 disabled:opacity-30 transition-all font-bold"
              >
                ←
              </button>
              <button 
                onClick={() => setStep(s => Math.min(results.visualization.length - 1, s + 1))}
                disabled={step === results.visualization.length - 1}
                className="w-8 h-8 rounded-lg bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center hover:bg-cyan-500/20 disabled:opacity-30 transition-all font-bold"
              >
                →
              </button>
            </div>
          </div>

          <div className="space-y-8">
            {/* Visual Array */}
            <div className="flex gap-2 justify-center overflow-x-auto py-4 scrollbar-hide">
              {results.visualization[step] && results.visualization[step].array && results.visualization[step].array.map((val, i) => {
                const { L, R, M } = results.visualization[step];
                let highlight = "border-white/10 bg-white/5 text-white/40";
                if (i === M) highlight = "border-cyan-500 bg-cyan-500/20 text-cyan-400 shadow-[0_0_20px_rgba(34,211,238,0.4)] scale-110 z-10 font-black";
                else if (i >= L && i <= R) highlight = "border-purple-500/30 bg-purple-500/10 text-white/80";
                
                return (
                  <div key={i} className={`min-w-[45px] h-14 flex items-center justify-center rounded-xl border font-mono text-sm transition-all duration-500 ${highlight}`}>
                    {val}
                  </div>
                );
              })}
            </div>
            {results.visualization[step] && (
              <div className="bg-white/5 p-4 rounded-2xl border border-white/5">
                <p className="text-center text-sm font-medium text-white/70 tracking-wide leading-relaxed">
                  <span className="text-cyan-400 font-bold mr-2">STEP {step + 1}:</span>
                  {results.visualization[step].label}
                </p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Optimization Sidebar */}
      <div className="md:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <h4 className="text-xs font-bold text-white/40 px-2 uppercase tracking-widest">Optimization Strategy</h4>
          <div className="space-y-3">
            {results.suggestions.map((s, i) => (
              <div key={i} className="flex gap-3 p-4 bg-white/[0.02] border border-white/5 rounded-2xl hover:border-cyan-500/20 hover:bg-white/[0.04] transition-all">
                <span className="text-cyan-400 flex-shrink-0">✦</span>
                <p className="text-xs leading-relaxed text-white/60">{s}</p>
              </div>
            ))}
          </div>
        </div>
        <div className="space-y-4">
          <h4 className="text-xs font-bold text-white/40 px-2 uppercase tracking-widest">Refactoring Blueprint</h4>
          <div className="space-y-3">
            {results.refactoring.map((r, i) => (
              <div key={i} className="flex gap-3 p-4 bg-white/[0.02] border border-white/5 rounded-2xl hover:border-purple-500/20 hover:bg-white/[0.04] transition-all">
                <span className="text-purple-400 flex-shrink-0">✓</span>
                <p className="text-xs leading-relaxed text-white/60">{r}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

    </div>
  );
};

export default AnalysisResults;
