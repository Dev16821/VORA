import React from 'react';

const CodeEditor = ({ code, setCode, language, setLanguage, onAnalyze, analyzing }) => {
  return (
    <div className="bg-zinc-900 border border-white/10 rounded-2xl overflow-hidden shadow-2xl transition-all hover:border-white/20">
      <div className="bg-white/5 px-6 py-4 flex items-center justify-between border-b border-white/10">
        <div className="flex gap-4">
          <select 
            value={language} 
            onChange={(e) => setLanguage(e.target.value)}
            className="bg-transparent text-xs font-bold text-cyan-400 outline-none cursor-pointer uppercase tracking-widest"
          >
            <option value="javascript" className="bg-zinc-900">JavaScript</option>
            <option value="python" className="bg-zinc-900">Python</option>
            <option value="java" className="bg-zinc-900">Java</option>
            <option value="cpp" className="bg-zinc-900">C++</option>
          </select>
        </div>
        <div className="flex gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-white/10"></div>
          <div className="w-2.5 h-2.5 rounded-full bg-white/10"></div>
          <div className="w-2.5 h-2.5 rounded-full bg-white/10"></div>
        </div>
      </div>
      <textarea 
        value={code}
        onChange={(e) => setCode(e.target.value)}
        spellCheck="false"
        className="w-full h-[450px] bg-transparent p-6 font-mono text-sm resize-none outline-none text-white/80 leading-relaxed scrollbar-thin scrollbar-thumb-white/10"
        placeholder="Paste your DSA code here (e.g., Binary Search, Quick Sort)..."
      ></textarea>
      <div className="p-4 bg-white/5 border-t border-white/10 text-right">
        <button 
          onClick={onAnalyze}
          disabled={analyzing}
          className={`px-8 py-3 rounded-xl font-black text-xs uppercase tracking-widest transition-all flex items-center gap-2 ml-auto ${
            analyzing ? 'bg-white/10 text-white/30' : 'bg-cyan-500 text-black hover:bg-cyan-400 shadow-[0_0_30px_rgba(34,211,238,0.2)]'
          }`}
        >
          {analyzing ? (
            <>
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
              Analyzing Module...
            </>
          ) : 'Analyze & Simulate →'}
        </button>
      </div>
    </div>
  );
};

export default CodeEditor;
